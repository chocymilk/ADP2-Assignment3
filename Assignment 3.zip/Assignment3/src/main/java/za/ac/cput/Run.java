/**
 *
 * @author Ameer Samsodien 220005060
 */

package za.ac.cput;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.stream.Collectors;



public class Run {
    ObjectInputStream input;
    
    ArrayList<Customer> customer = new ArrayList<Customer>();
    ArrayList<Supplier> supplier = new ArrayList<Supplier>();
    
    public void readFile(){
        try{
            Object object1 = null;
            while (!(object1 = input.readObject()).equals(null)){
                if (object1 instanceof Customer){
                    customer.add((Customer)object1);
                    System.out.println("adding to object customer" + ((Customer) object1).getFirstName());
                }
                if (object1 instanceof Supplier){
                    supplier.add((Supplier) object1);
                    System.out.println("adding to object supplier" + ((Supplier) object1).getName());
                }
            }
                    System.out.println("Completed read");
        }
        catch (ClassNotFoundException ioe){
            System.out.println("error reading ser file " + ioe.getMessage());
        }
        catch (IOException ioe){
            System.out.println("End: " + ioe.getMessage());
        }
        finally{
            closeFile();
        }
    }
    
    public void openFile(){
        try{
            input = new ObjectInputStream (new FileInputStream("stakeholder.ser"));
            System.out.println("ser file opened for reading");
        }
        catch(IOException ioe){
            System.out.println("error opening file");
        }
    }
    
    public void closeFile(){
        try{
            input.close();
        }
        catch(IOException ioe){
            System.out.println("error closing file " + ioe.getMessage());
        }
    }
    
    public void sortCustomerAndStakeholder(){
        Collections.sort(customer, (customer1, customer2) ->{
            return customer1.getStHolderId().compareTo(customer2.getStHolderId());
        });
    }
    
    
    private int getAge(String date){
        LocalDate date1 = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
        LocalDate date2 = LocalDate.now();
        return Period.between(date1, date2).getYears();
    }
    
    
    public String reformatDateOfBirth(Customer customer){
        DateFormat dateFormat = new SimpleDateFormat("dd MM yyyy");
        try{
            Date dob = new SimpleDateFormat("yy-MM-dd").parse(customer.getDateOfBirth());
            return dateFormat.format(dob);
        }
        catch (Exception e){
            System.out.println("error with reformating " + e.getMessage());
        }
        return null;
    }
    
    public void writeCustomer(){
        try{
            FileWriter writer = new FileWriter("customerOutFile.txt"); 
            writer.write("================== CUSTOMERS =======================\n");
            writer.write(String.format("%-10s\t%-10s\t%-10s\t%-15s\t%-10s\n", "ID", "Name", "Surname", "Date of Birth", "Age"));
            writer.write("====================================================\n");
            
            for(Customer cust: customer) {
                String output = String.format("%-10s\t%-10s\t%-10s\t%-15s\t%-10s\n",cust.getStHolderId(), cust.getFirstName(), cust.getSurName(), reformatDateOfBirth(cust), getAge(cust.getDateOfBirth()));
                writer.write(output + "\n");
            }
            
            
            writer.write("Number of customers who can rent: " + customer.stream().filter(Customer::getCanRent).collect(Collectors.toList()).size() + "\n");
            writer.write("Number of customers who cannot rent: " + customer.stream().filter(c -> !c.getCanRent()).collect(Collectors.toList()).size());
            writer.close();
            
            
        }catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error Writing to file");
        }
    }
    
    
    public void sortSuppliers(){
        Collections.sort(supplier,(customer1, customer2) ->{
            return customer1.getName().compareTo(customer2.getName());
        }
        );
    }
    
    
    public void writeSupplier(){
        try{
            FileWriter writer = new FileWriter("supplierOutFile.txt");
            writer.write("================== SUPPLIERS ==========================\n");
            writer.write(String.format("%-10s\t%-10s\t%-10s\t%-10s\n", "ID", "Name", "Prod Type", "Description"));
            writer.write("====================================================\n");
            
            for(Supplier sup: supplier){
                String output = String.format("%-10s\t%-10s\t%-10s\t%-10s\n", sup.getStHolderId(), sup.getName(), sup.getProductType(), sup.getProductDescription());
                writer.write(output + "\n");
            }
            writer.close();
        }
        catch (Exception e){
            e.printStackTrace();
            System.out.println("error writing file");
        }
    }
    
    public static void main(String[] args) {
        Run runAssignment = new Run();
        runAssignment.openFile();
        runAssignment.readFile();
        runAssignment.sortCustomerAndStakeholder();
        runAssignment.writeCustomer();
        runAssignment.sortSuppliers();
        runAssignment.writeSupplier();
        runAssignment.closeFile();
        
    }
    
}
